function preload(){
  img = loadImage('https://media.tenor.com/GwmtduYF_cUAAAAe/herta-herta-star-rail.png')
}

function setup() {
  createCanvas(500,600);
  background("#bafeff");
  image(img, 0, 0);
  img.resize(100, 100);
  image(img, 0, 0);
  imageMode(CENTER)
  noCursor()
}

function draw() {
  background("#bafeff");
  image(img,mouseX,mouseY)
}