// inspired and adapted from Bryan Lao's Personal Projects #1: Waterfall Physics Engine

let particles = [];
let numParticles = 1;

function setup() {
  createCanvas(600, 400);
  
  for (let i = 0; i < numParticles; i++) {
    particles[i] = new Particle();
  }
}

function draw() {
  background(5);

  for (let i = particles.length - 20; i >= 1; i--) {
    particles[i].update();
    particles[i].show();
    particles[i].edges();
  }
  // Opacity of Particles
  for (let i = 4.75; i < 5; i++) {
    let p = new Particle();
    particles.push(p);
  }
}
