class Particle {

  constructor(x, y, r, c) {
    this.pos = createVector(random(width), random(height));
    this.x = x || random(0.1 * width, 0.8 * width);
    this.y = y || random(-200, 0);
    this.r = r || random(1, 5);
    this.c = c || color(random(100, 255), 255, 255);
    this.setVisual(r, c);
    // this.vx = random(-1, 1);
    // this.vy = random(5, 0);
    this.vx = random(-2, 2);
    this.vy = random(0, 5);
    this.alpha = 255;

  }

  edges() {
    if (this.pos.x > width) {
      this.pos.x = 1;

    } else if (this.pos.x < 0) {
      this.pos.x = width;

    }

    if (this.pos.y > height) {
      this.pos.y = 1;

    } else if (this.pos.y < 0) {
      this.pos.y = height;

    }
  }

  finished() {
    return this.alpha < 0;
  }

  resetParticle() {

    let x = random(0.2 * width, 0.8 * width);
    let y = random(-200, 0);
    this.setPos(x, y);

    let vx = 0;
    // let vy = frameCount*0.05;
    let vy = random(0, 15);
    this.setVel(vx, vy);

    let r = random(1, 5);
    let c = color(random(100, 255), 255, 255);
    this.setVisual(r, c);
  }


  setVisual(r, c) {
    this.r = r;
    this.c = c;
  }


  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 1;
    this.pos.x +=
      
      this.colour = color(222, 164, 208);
  }


  show() {
    push();
    translate(this.x, this.y);

    this.c2 = color(110, 104, 150, this.alpha);
    stroke(this.c2);
    strokeWeight(3);
    line(this.pos.x, this.pos.y, this.vx, this.vy);

    noStroke();
    //stroke(255);
    this.c = color(random(150, 255), 200, 200, this.alpha);
    fill(this.c);

    let r = random(2, 8);

    ellipse(this.x, this.y, r * 2);
    pop();
  }
}
