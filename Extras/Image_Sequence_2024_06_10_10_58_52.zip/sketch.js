var numFrames = 4;
var frame = 0;
var images = new Array(numFrames);

function preload() {
  images[0] = loadImage("1.jpg");
  images[1] = loadImage("2.jpg");
  images[2] = loadImage("3.jpg");
  images[3] = loadImage("4.jpg");
}

function setup() {
  createCanvas(650, 650);
  frameRate(15);
  background(255);
}

function draw() {
  background(220);
  frame ++;
  if (frame == numFrames) frame = 0;
  image(images[frame], 0,0);
}