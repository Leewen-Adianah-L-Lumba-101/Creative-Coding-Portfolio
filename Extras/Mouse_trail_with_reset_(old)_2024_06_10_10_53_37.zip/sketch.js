let c1, c2;

function setup() {
  createCanvas(500, 500);
  c1 = color("#f7f6c6");
  c2 = color("#0d5ad6");

  for (let y = 0; y < height; y++) {
    n = map(y, 0, height, 0, 1);
    let newc = lerpColor(c1, c2, n);
    stroke(newc);
    line(0, y, width, y);
  }
}

function draw() {
  //background(220);
  // console.log(c2);
  x = random(0, width);
  y = random(0, height);
  d = random(10, 50);
}

let positions = [];

function draw() {
  positions.push(mouseX);
  positions.push(mouseY);

  for (let i in positions) {
    let x = positions[i];
    let y = positions[i + 1];
    fill(random(255, 255));
    ellipse(mouseX, mouseY, 10, 10);
  }

  if (positions.length > 20) {
    positions.shift();
    positions.shift();
  }
}

function mousePressed() {
  setup();
}