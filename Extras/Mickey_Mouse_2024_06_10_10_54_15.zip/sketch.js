function setup() {
  createCanvas(500, 500);
}

function draw() {
  background("#48e5e8");
  fill("#e33627");
  noStroke();
  ellipse(250,265,200);
  ellipse(150,150,150);
  ellipse(350,150,150);
  
  let hoff = 10;
  
  let x = winMouseX;
  let y = winMouseY;
  
  let cx = width/2;
  let cy = height/2;
  
  let hx = map(x,0,width,-hoff,hoff);
  let hy = map(y,0,height,-hoff,hoff);
  
  let shadow = 5;
  
}