let bubble1;
let bubble2;

let bubbles = [];

function setup() {
  createCanvas(600, 400);
  bubble1 = new object();
  bubble2 = new object();
  bubble3 = new object();
  
  for (let l = 0; l < 90; l++); {
    bubbles = new object(90);
  }
}

function draw() {
  background(89);
  bubble1.move();
  bubble1.show();
  bubble2.move();
  bubble2.show();
  bubble3.show();
  bubble3.move();
  bubbles.show();
  bubbles.move();

}

class object {
  constructor() {
    this.x = 200;
    this.y = 100;

  }
  
  move() {
    this.x = this.x + random(-5,10);
    this.y = this.y + random(-5,10);
  }
  
  show() {
    stroke(255);
    strokeWeight(4);
    noFill();
    ellipse(this.x,this.y,10,10);
  }
}