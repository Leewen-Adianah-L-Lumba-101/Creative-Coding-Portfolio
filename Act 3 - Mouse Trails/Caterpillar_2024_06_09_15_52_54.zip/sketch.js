//declare empty arrays for x and y coordinates
const posY = [];
const posX = [];
const wormLength = 50 // amount of coordinates stored

function setup() {
  createCanvas(500, 500);

  noStroke();
  fill(50,200,100);
}

function draw() {
  background("#ecf54e");
  //loop through the stored coordinates and draw an ellipse at each coordinate
  for(let i = 0; i < posX.length; i++){
    //get x coordinate at index i in the array
    let x = posX[i];
    //get y coordinate at index i in the array
    let y = posY[i];
    //draw ellipse using x and y
    fill("#1B5A36");
    ellipse(x+10,y,50);
    
    fill(50,200,100);
    ellipse(x,y,50);
    
    fill(5);
    ellipse(x+10,y+10,5);
    
    fill(5);
    ellipse(x-10,y+10,5);
  }
}

function mouseMoved(){
  //when mouse is moved, push mouse coordinates to arrays (head of the worm)
  posX.push(mouseX);
  posY.push(mouseY);
  //if worm gets too long, remove first coordinates from the arrays (tail of the worm)
  if(posY.length > wormLength){
    posX.shift();
    posY.shift()
  }
}