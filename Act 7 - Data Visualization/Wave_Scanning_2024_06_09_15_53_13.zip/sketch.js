let inc = 0.01;
let start = 0;
var word = "Data Visualization";
var font1;

function preload(){
  font1 = loadFont('R&C-Demo.otf');
}

function setup() {
  createCanvas(500, 400);
}

function draw() {
  background(51);
  
  noFill();
  rect(10,110,340,200);
  
  stroke(255);
  noFill();
  beginShape();
  let xoff = start;
  for (let x = 0; x < width; x++) {
    stroke(120);
    point(x,random(height));
    stroke(305);
    // let y = random(height);
    let y = noise(xoff) * height;
    vertex(x, y);
    
    xoff += inc;
  }
  endShape();
  
  start += inc;
  
  beginShape();
  let xoff2 = start;
  for (let x = 0; x < width; x++) {
    stroke(320);
    // let y = random(height);
    let y = noise(xoff) * height;
    vertex(x, y);
    
    xoff += inc;
  }
  endShape();
  
  start += inc;
  
  //noLoop();
  
  fill("rgb(0,0,0)");
  textFont(font1,20);
  textAlign(CENTER);
  text(word,100,59);
  
  textFont(font1,10);
  text('Data Visualization 298', 90, 90);
  
  strokeWeight(0.5);
  line(0, 200, random(100), 200);
  strokeWeight(0.5);
  //first argument offset to X, third concerns length
  line(0, 250, random(100), 250);
  
}
