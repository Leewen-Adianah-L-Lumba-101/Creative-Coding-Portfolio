var sections = [20, 130, 50, 39, 78, 51];
var sections2 = [20, 10, 30, 60, 40, 50];

var diameter = 300;
var lastAngle = 0;

function setup() {
  createCanvas(700, 490);
  background("#286F3D");
  colorMode(RGB, 20, 100, 100);
  
  noStroke();
  
  translate(-150,0);
  for (var i= 0; i< sections.length; i++) {
    var n = sections[i];
    var c = map(n, 0, max(sections), 0, 100);
    
    fill(10, 400, c);

    arc(width/2, height/2, diameter, diameter, lastAngle, lastAngle+radians(n));
      //Draws an arc with the center at (width / 2, height / 2), with the specified diameter, starting at lastAngle and ending at lastAngle + radians(n).

    lastAngle+= radians(n);
  }
  
  translate(320,10);
  secondchart(sections2);
}

function secondchart(data) {
  
  for (var i= 0; i< data.length; i++) {
    var n = data[i];
    var c = map(n, 0, max(data), 0, 100);
    fill(220, 100, c);
    arc(width/2, height/2, diameter, diameter, lastAngle, lastAngle+radians(n));
    lastAngle+= radians(n);
  }
  
}

// function preload() {
//   data = loadStrings("color_srgb.csv");
// }

// function setup() {
//   createCanvas(650, 490);
//   background("#f0f0f0");
//   fill("#111111"); 
//   // title for the diagram
//   textSize(50);
//   text("Colours", 240, 50);
  
//   // customize the text to use later
//   textAlign(CENTER, CENTER);
//   textSize(5); 
  
//   let rowCount = data.getRowCount();

//   for (let i = 0; i < colourin; i++) {
//   }
// }
