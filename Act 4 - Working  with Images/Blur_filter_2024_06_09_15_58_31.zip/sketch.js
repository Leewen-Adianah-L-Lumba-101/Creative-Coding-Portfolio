var img;

function preload() {
  img = loadImage("Thegodhand.jpg");
}

function setup() {
  createCanvas(365, 360);
}

function draw() {
  background(220);
  
  image(img,0,0);
  
  var v = map(mouseX, 0, width, 0, 5);
  filter(BLUR,v);
  filter(GRAY,10);
}