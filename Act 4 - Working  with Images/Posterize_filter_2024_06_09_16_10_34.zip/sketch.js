var img2
function preload() {
  img2 = loadImage('perfectBlue.jpg');
}

function setup() {
  createCanvas(280, 280);
}

function draw() {
  background(220);  
  image(img2,0,0,img2.width/2,img2.height/2);
  var v = map(mouseX, 0, width, 0, 8);
  filter(POSTERIZE,v);
  
}