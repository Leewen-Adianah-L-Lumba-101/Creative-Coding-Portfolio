// lol
var img, x, y;
function preload() {
  img = loadImage('Screenshot 2024-03-20 104557.png');
  
}
function setup() {
  createCanvas(270, 340);
  background (0);
  noStroke();
  img.resize(0,259);
}

function draw() {
  x = random(width) ;
  y = random(height) ;
  image(img,0,0,img.width/0.75,img.height/0.75);
  var c = img.get(x/2, y);
  fill(c[0],c[1],c[2],200);
  rect(x,y,50,10);
  fill(c[1],c[0],c[1],100);
  rect(x,y,50,10);
}