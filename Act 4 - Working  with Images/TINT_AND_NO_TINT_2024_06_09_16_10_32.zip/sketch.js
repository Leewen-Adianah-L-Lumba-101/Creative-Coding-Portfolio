var img;
function preload() {
  img = loadImage('gutswithblunt.jpg');
}


function setup() {
  createCanvas(500, 480);
}

function draw() {
  background(220);
  image(img,0,0,img.width/3,img.height/3);
  
  tint(240,0,0);
  image(img,0,img.height/3,img.width/3, img.height/3);
  noTint();
  
  textSize(40);
  fill(5);
  noStroke();
  strokeWeight(4);
  text('Tint', 340, 380);
  text('No Tint', 313, 140);
  
}