var img, x, y;
function preload() {
  img = loadImage('statue.jpg');
  
}
function setup() {
  createCanvas(300, 400);
}

function draw() {
  background(220);
  image(img,0,0,img.width/3,img.height/3);
  x = mouseX ;
  y = mouseY ;
  var c = get(x, y);
  fill(c)
  ellipse(x,y,100,100);
  noStroke();
}