var mySound;
var brass;
var clap;
var rifle;
let rectWidth;
let angle = 0;
let size1 = 0;
let size2 = 0;

function preload() {
  mySound = loadSound("amenbreak.mp3");
  brass = loadSound("brass.wav");
  bass = loadSound("bass1.wav");
  clap = loadSound("clap.wav");
  rifle = loadSound("rifle.wav");

}

function setup() {
  createCanvas(500, 500);
  background(220);
  rectWidth = width / 4;


  mySound.setVolume(0.2);
  brass.setVolume(0.7);
  bass.setVolume(1);
  rifle.setVolume(0.8);
  clap.setVolume(0.5);
  
  angleMode(DEGREES);
  rectMode(CENTER);

}

function draw() {
  
  text("Press A B C D E", 50, 50);
  
  push();
  translate(250, 250);
  rotate(-angle * 2);
  fill(50, 100, 255);
  rect(0, 0, size1, size2);
  stroke(5);
  pop();
  
  angle = angle + 0.1
  size1 += 0.1
  size2 += 0.1
}

function keyTyped() {
  
  let keyIndex = -1;
  randFill_r = Math.floor(Math.random() * 255 + 1);
  randFill_g = Math.floor(Math.random() * 255 + 1);
  randFill_b = Math.floor(Math.random() * 255 + 1);
  fill(randFill_r, randFill_g, randFill_b);
  
  if (key == 'a') {
    mySound.play(); 
    background("#264236");
    
    let x = map(keyIndex, 0, 25, 10, width - rectWidth);
    noStroke();
    circle(random(500), random(500), random(height));
    size1 -= 10
    size2 -= 10
  }
  
  if (key == 'b') {
    brass.play();
    background("#60BA32");
    angle = angle - 10;

    let x = map(keyIndex, 0, 25, 10, width - rectWidth); 
    rect(random(500), random(500), rectWidth, random(255));
    size1 += 20
    size2 += 20
  }
  
  if (key == 'c') {
    bass.play();
    background("#397768");
    angle = angle + 10;

    
    let x = map(keyIndex, 0, 25, 10, width - rectWidth);
    rect(random(500), random(500), rectWidth, random(255));
    size1 += -20
    size2 += -20
  }
  
  if (key == 'd') {
    clap.play();
    background("#BBAB1B");
    angle = angle + 5;
    
    let x = map(keyIndex, 10, 25, 10, width - rectWidth);
    noStroke();
    rect(random(500), random(500), rectWidth, random(255));
  }
  
  if (key == 'e') {
    rifle.play();
    background("#525A66");
    angle = angle - 5;
  
    let x = map(keyIndex, 0, 25, 10, width - rectWidth);
    noStroke();
    triangle(random(490), random(490), random(490), random(255),                 random(255), random(255));
    triangle(random(500), random(500), random(500), random(255),                 random(255), random(255));
    size1 += -10
    size2 += -10
    
  }
  
}