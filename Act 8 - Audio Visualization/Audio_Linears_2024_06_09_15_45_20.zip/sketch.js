var mySound, fft;

function preload() {
mySound= loadSound('nhk.mp3');
}


function setup() {
  createCanvas(500, 500);
  background("#96a3a2");
  fft = new p5.FFT();
  mySound.setVolume(1);
  mySound.play();
  noStroke();
  fill(255);
}


function draw(){
  translate(-100,0);
  background(255);
  
  fft.analyze();
  var fftLin = fft.linAverages(1020);
  for (var i= 0; i< fftLin.length; i++) {
    var x = map(i, 0, fftLin.length, 100, width*10);
    var h = map(fftLin[i], 0, 255, 0, height/2);
    rect(x, height -h, width*5 / fftLin.length, h );

  fill("#91A888");
  var fftLin = fft.linAverages(1020);
  var x = map(i, 0, fftLin.length, 0, width*10);
  var h = map(fftLin[i], 0, 255, 0, height);
  rect(x, height - h, width*5 / fftLin.length, h );
  } 
  
  push();
  translate(105,5);
  noFill();
  strokeWeight(2);
  stroke("#4f5e5d");
  square(0,0, 490);
  pop();
  
  push();
  translate(105,8);
  text("Now playing - Nhk!?", 40, 40);
  pop();
}