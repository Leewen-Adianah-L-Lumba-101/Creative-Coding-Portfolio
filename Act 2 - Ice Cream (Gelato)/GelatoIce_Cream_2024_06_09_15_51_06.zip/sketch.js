// posterise shader filter on off-screen graphics
//
// An example sketch showing the p5.filterShader library
// https://github.com/BarneyWhiteman/p5.filterShader

let posteriseShader;

// Off-screen graphics
let gfx;

const minBands = 10;
const maxBands = 80;

function preload() {
  // Load the shader to use as a filter
  posteriseShader = loadShader("filter.vert", "filter.frag");
}

function setup() {
  createCanvas(600, 450);
  
  // Create an off-screen graphics to draw on
  gfx = createGraphics(width/2, height, WEBGL);
  gfx.noStroke();
  
}

function draw() {
  
  gfx.orbitControl();
  gfx.rotateY(frameCount * 0.01);
  
  // Draw on the off-screen graphics
  gfx.push();
  
  gfx.background("#B97474");
  
  // Give some lighting
  const t = millis()/1000;
  
  gfx.directionalLight(255, 0, 255, cos(t/2), sin(t), -1);
  gfx.directionalLight(255, 255, 0, sin(t/2), cos(t), -1);
  
  // Draw a sphere
  gfx.fill("#bd752d");
  gfx.noStroke();
  
  gfx.cylinder(50,-25,70);
  gfx.translate(0,-25);
  
  gfx.translate(0, 70);
  gfx.cone(50, 100);
  
  gfx.noStroke();
  gfx.translate(0, -65);  
  
  gfx.fill("#FF7A7A");
  gfx.sphere(50);
  
  gfx.fill("#FFFFFF");
  gfx.translate(0, -40);
  gfx.sphere(38);
  
  gfx.fill("#D32727");
  gfx.translate(0, -45);
  gfx.sphere(10);

  gfx.pop();
  
  // Draw image before filter (left)
  image(gfx, 0, 0, width/2, height);
  
   // Set uniform and apply filter
  let numBands = map(mouseY, 0, height, minBands, maxBands);
  numBands = constrain(numBands, minBands, maxBands);
  posteriseShader.setUniform("num_bands", numBands);
}