var font1;

function preload(){
  font1 = loadFont('MONALIZED.ttf');
}

function setup() {
    createCanvas( 500, 200 );
}

function draw() {
  background("#050a12");

  textSize(36);
  textFont(font1);
  r = random(255);
  g = random(255); 
  b = random(255); 
  a = random(1,255);
  
  noStroke();
  fill(r, g, b, a);

  let message = "BATH SPA UNIVERSITY";
  let spacing = 26;

  for (let i = 0; i < message.length; i++) {
    stroke(r,g,b,a);
    strokeWeight(4);
    let x = 10 + i * spacing;
    let y = 100 + sin(frameCount * 0.1 + i) * 5;
    text(message.charAt(i), x, y);
    
    frameRate(30);
  }
}



