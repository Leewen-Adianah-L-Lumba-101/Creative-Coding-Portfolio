var word = "Hello World";
var font1;

function preload(){
  font1 = loadFont('Retron2000.ttf');
}

var points;

function setup() {
createCanvas(800, 300);
stroke(0);

points = font1.textToPoints(word, 90,100,100, { sampleFactor: 0.15 });
background(255);


for (var i = 0; i < points.length; i++) {
  var p = points[i];
  ellipse(p.x,p.y,3,3);
}
}
