var word = "Hello World";
var font1;

function preload(){
  font1 = loadFont('Retron2000.ttf');
}

function setup() {
  createCanvas(600, 400);
  background("#000000");
  fill("#038207");
  textFont(font1,90);
  textAlign(CENTER);
  text(word,width/2,220);
}

function draw() {
}

