var letters = [ [ 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1 ], //A 

[ 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0 ], //B 

[ 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1 ], //C 

[ 1,1,1,0,1,0,0,1,1,0,0,1,1,0,0,1,1,1,1,0]]; //D ;


var blockSize = 25; 

function setup() { 
  createCanvas(525, 400); 
  noStroke();
  background(5);

  fill(255); 

  for(var i = 0; i < letters.length; i++) {
     var xPos = 1, yPos = 1;
        for(var j = 0; j < letters[i].length; j++) {
            if(letters[i][j] == 1) { 
              ellipse(xPos, yPos, blockSize, blockSize);
             } 

             xPos += blockSize; 
             if(j % 4 == 3) {
              xPos = 0;
              yPos += blockSize;
            } 
       } translate(blockSize * 6, 100); //letter spacing
    } 
}

