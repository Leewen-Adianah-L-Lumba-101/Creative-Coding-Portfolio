function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background("#1a1a1a");
  
  fill("#F5FCF5");
  square(100, 100, 200);
  
  noStroke();
  fill("#eb3734");
  circle(200, 200, 20);
  describe('A red circle with black outline in the middle of a 220 canvas.');
  
  fill("#3446eb");
  rect(150, 190, 20, 20);
  describe('A white rectangle with black outline in the middle of a 220 canvas.');
  
  fill("#3aeb34");
  triangle(252, 209, 230, 209, 240, 192);
  
}