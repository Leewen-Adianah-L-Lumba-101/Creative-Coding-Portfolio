function setup() {
  createCanvas(500, 500, WEBGL);
  normalMaterial();
  describe(
    'Camera orbits around abstract piece when mouse is hold-clicked & then moved.'
  );
}

function draw() {
  background("#366b54");
  orbitControl();
  // orbitControl(1, 1, 1, {freeRotation: true});

  rotateY(0.1);
  arc(300, 300, 250, 250, 399, HALF_PI);
  noFill();
  arc(50, 50, 240, 260, PI, PI + QUARTER_PI);

  
  fill("#fc0076");
  circle(20, 20, 20);
  
  stroke('##fff2e3');
  strokeWeight(4);
  
  arc(-290, 24, 290, 285, 410, PI + QUARTER_PI);
  arc(0, 0, 290, 285, 250, PI + QUARTER_PI);
  arc(30, 400, 290, 285, 250, PI + QUARTER_PI);
  arc(290, 224, 290, 285, 299, PI + QUARTER_PI);
    
  fill("#21ccb8");
  arc(12, 299, 120, 360, 399, PI + QUARTER_PI);
  
  square(10,10,500);
  fill("#e67c20");
  square(-500,150,500);
  
}