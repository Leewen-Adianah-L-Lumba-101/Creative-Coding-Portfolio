// Global variables
let lives = 3
let score = 0
let player
let settings = { gravity: null }
var answer = 1
let timer = 2

var star2Radius = 1.5;		//stars that are closest 
var star2Speed = 2;
var star2Num = 20;

var star2 = [];		

let textshow = true

function preload() {
  bg = loadImage('bg.png');
  ost = createAudio("Nu Slumber.mp3");
  ost2 = createAudio("AMBIENTPOP.mp3");
}

function setup() {
  createCanvas(600, 400)
  settings.gravity = createVector(0, 1)
  player = new Player(settings, width / 2, height / 2, 40, 40,3);
  
  for (var j = 0; j < star2Num; j++) {
    star2[j] = new Star2();
  }
}

// draw executes again and again (~60 fps)
function draw() {
  background(bg);
  ost.play();
  player.show() // cf player.js
  player.update() // cf player.js
  
  if (textshow) {
    text("Use the directional keys to move", 310, 50);
  }
  
  text("Lives: " + lives, 309, 70);
  text("Score: " + score, 309, 85);
  textAlign(CENTER);

  if (score > 25) {
    ost.pause();
    background(255);
    text("YOU WIN.", width/2, height/2);
    textSize(20);
    ost2.play();
    ost2.loop();
    
    // Stars in the back
    for (var j = 0; j < star2Num; j++) {
      star2[j].move();
      star2[j].display();
    }
    
    player.show() // cf player.js
    player.update() // cf player.js
    
  }
  
  else if (answer == 1) {
    pass = false

    push();
    textSize(15);
    text("Simon says Jump.",100,400);

    // Timer
    textSize(100);
    text(timer, 550,height/1);
    pop();
    if (frameCount % 60 == 0 && timer > 0) {
      timer--;
    }  
    // Check if player actually jumped
    if (timer > 0 && keyCode == UP_ARROW) {
      score+= 1;
      pass = true
      timer = 2;
      answer = int(random(1,7))
    
    }
    
    if (timer == 0 && pass == false) {
      lives--;
      timer = 2;
      answer = int(random(1,7))
    }

  }
  
  else if (answer == 2) {
    pass = false

    push();
    textSize(15);
    text("Simon says go east.",100,400);

    // Timer
    textSize(100);
    text(timer, 550,height/1);
    pop();
    if (frameCount % 60 == 0 && timer > 0) {
      timer--;
    }  
    
    // Check if player went right
    if (timer > 0 && keyCode == RIGHT_ARROW) {
      score+= 1;
      pass = true
      timer = 2;
      answer = int(random(1,7))
    }
    
    if (timer == 0 && pass == false) {
      lives--;
      timer = 2;
      answer = int(random(1,7));
    }
  }
  
  else if (answer == 3) {
    timer = 2
    pass = false
    
    push();
    textSize(20);
    text("Simon says go west.",100,400);
    
    // Timer
    textSize(100);
    text(timer, 550,height/1);
    pop();
    
    if (frameCount % 60 == 0 && timer > 0) {
      timer--;
    }  
    // Check if player went left
    if (timer > 0 && keyCode == LEFT_ARROW) {
      score+= 1;
      pass = true
      timer = 2;
      answer = int(random(1,7));
    }

    if (timer == 0 && pass == false) {
      lives--;
      timer = 2;
      answer = int(random(1,7));
    }
  }
  
  else if (answer == 4) {
    pass = false
    push();
    textSize(20);
    text("Simon says sink.",100,400);
    
    // Timer
    textSize(100);
    text(timer, 550,height/1);
    if (frameCount % 60 == 0 && timer > 0) {
      timer--;
    }  
    // Check if player sank
    if (timer > 0 && keyCode == DOWN_ARROW) {
      score+= 1;
      pass = true
      timer = 2;
      answer = int(random(1,7))
    }
    
    if (timer == 0 && pass == false) {
      lives--;
      timer = 2;
      answer = int(random(1,7))
    }
    pop();
  }
  
  else if (answer == 5) {
    pass = true
    push();
    textSize(20);
    text("Jump!",100,400);
    
    // Timer
    textSize(100);
    text(timer, 550,height/1);
    pop();
    if (frameCount % 60 == 0 && timer > 0) {
      timer--;
    }  
    // Check if player jumped, penalty: -2 point
    if (timer > 0 && keyCode == UP_ARROW) {
      score -= 2;
      lives += 2;
      answer = int(random(1,7))
      timer = 2;
    }
    
    if (timer == 0 || pass == false) {
      answer = int(random(1,7))
    }
  }
    
  else if (answer == 6) {
    pass = true
    push();
    textSize(20);
    text("Go left!",100,400);
    
    // Timer
    textSize(100);
    text(timer, 550,height/1);
    pop();
    if (frameCount % 60 == 0 && timer > 0) {
      timer--;
    }  
      
    // Check if player went left, penalty: -2 point
    if (timer > 0 && keyCode == LEFT_ARROW) {
      score -= 2;
      lives += 2;
      answer = int(random(1,7))
      timer = 2;
    }
    
    if (timer == 0 || pass == false) {
      answer = int(random(1,7))
    }
  }
  
  if (lives < 1) {
    background(5);
    text("GAME OVER", width/2, height/2);
    textSize(20);
  }
}



// keyPressed executes when a key is pressed
function keyPressed() {
  textshow = false
  
  switch(key) {
    case 'ArrowLeft':
      player.move('left', true)
      break
    case 'ArrowUp':
      player.move('up', true)
      break
    case 'ArrowRight':
      player.move('right', true)
  }
}
  
function keyReleased() {
  switch(key) {
    case 'ArrowLeft':
      player.move('left', false)
      break
    case 'ArrowRight':
      player.move('right', false)
  }
}


function Star2() {
  this.x = random(0, width);
  this.y = random(0, height);
  
  this.display = function() {
    fill(0);
    noStroke();
    ellipse(this.x, this.y, star2Radius*2, star2Radius*2);
  }
  
  this.move = function()
  {
    if (this.y > height)		//if the star goes below the screen
    {
      this.y = 0;						//reset to the top of the screen
      this.x = random(0,width);
      let alphaValue = alpha("black");
    } 
    else
    {
      this.y += star2Speed;
    }
  }
}