class Player {
  constructor(settings, x, y, width, height, health) {
    this.settings = settings
    this.pos = createVector(x, y) // position
    this.vel = createVector(0, 0) // velocity
    this.acc = createVector(0, 0) // acceleration
    this.width = width
    this.height = height
    this.maxVel = 6 
    this.direction = { left: false, right: false }
    this.forces = createVector(0, 0);
  }

  // Shows a rectangle at the position of the player
  show() {
    const { pos, width, height } = this
    
    noStroke() // or stroke(0) for a black stroke, stroke(0, 0, 255) for a blue stroke
    fill("rgb(38,38,38)"); // color of the fill
    
    // make a rectangle using the current stoke and fill values
    rect(pos.x, pos.y, width, height);
  }
  
  // Updates the position and velocity of the player
  update() {
    const { settings, forces, acc, vel, pos, direction, maxVel } = this
    
    // Apply forces to the acceleration (gravity and eventually jump)
    let gravity = settings.gravity.copy() // .copy() to copy without the pointer
    forces.add(gravity) // add is a vector method to add a vector
    acc.add(this.forces)
    forces.setMag(0) // setMag(0) sets the magnitude to 0 to avoid accumulation
    
    
    // The the x velocity according to user input
    // and update y velocity according to the acceleration
    vel.x = 0
    if (direction.left) { vel.x = -maxVel }
    else if (direction.right) { vel.x = maxVel }
    vel.add(acc)
    acc.setMag(0)
    
    // Update the position according to the velocity
    pos.add(vel)
    
    // ------CONSTRAINTS
    // Limit the movement to the borders of the canvas, defined just after
    this.constrainPosition()
  }
  
  // Limits the movement to the borders of the canvas
  constrainPosition() {
    const { pos, vel } = this
    // Stop the player from going too far left or right (walls)
    const maxX = width - this.width
    if (pos.x < 0) { pos.x = 0 }
    if (pos.x > maxX) { pos.x = maxX }
    // Stop the player from going too far up or down (ceiling and floor)
    const maxY = height - this.height
    if (pos.y < 0) {
      pos.y = 0
      vel.y = 0
    }
    if (pos.y > maxY) {
      pos.y = maxY
      vel.y = min(vel.y, 0)
    }
  }
  
  // Called on keyPressed or keyReleased, save the inputs of the user
  move(direction, isMoving) {
    if (direction === 'left' || direction === 'right') {
      this.direction[direction] = isMoving
    } else if (direction === 'up' && this.pos.y >= (height - this.height)) {
      const jump = createVector(0, -15)
      this.forces.add(jump)
    }
  }
}